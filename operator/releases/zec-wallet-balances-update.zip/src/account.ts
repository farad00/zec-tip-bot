import type { IncomingMessage, ServerResponse } from 'node:http';
import { randomBytes } from 'node:crypto';
import { tokenRequest } from './auth.js';
import { oauthHeader } from './oauth.js';
import type { Config } from './config.js';
import type { State } from './state.js';
import { TipStore, formatZat } from './tip-store.js';
import { CSS } from './ui.js';
import {readWalletHealth,walletHealthPanel,type WalletHealth} from './wallet-health.js';
import {WalletAccountProvisioner,type AccountWalletBackend,type AccountWalletHealth,type WalletBalance} from './wallet-accounts.js';
import {WalletAccountClient} from './wallet-account-client.js';
const escape=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
function cookie(req:IncomingMessage,name:string) { const entries=(req.headers.cookie??'').split(';').map(s=>s.trim()).filter(s=>s.startsWith(name+'='));return entries.length===1?entries[0]!.slice(name.length+1):''; }
async function fields(req:IncomingMessage) {
  if ((req.headers['content-type']??'').split(';')[0]!=='application/x-www-form-urlencoded') throw new Error('Invalid form.');
  let size=0; const parts:Buffer[]=[];
  for await(const chunk of req) {const bytes=Buffer.from(chunk);size+=bytes.length;if(size>4096)throw new Error('Invalid form.');parts.push(bytes);}
  const values=new URLSearchParams(Buffer.concat(parts).toString('utf8'));
  for(const key of values.keys())if(values.getAll(key).length!==1)throw new Error('Invalid form.');
  return values;
}
const reasons:Record<string,string>={setup_required:'Configure and enable tipping first.',wallet_unavailable:'Both wallets must be ready. No transfer was queued.',self_tip:'Self-tipping is disabled.',daily_limit:'Your daily spending limit would be exceeded.',stale_command:'The command predates your latest settings or is too old.',mainnet_disabled:'Hosted Mainnet transfers are disabled.',tips_paused:'Automatic tips are paused.'};
function page(body:string) {return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title>ZEC Tip Bot — private tip settings</title><style>'+CSS+'.account-input{display:block;width:100%;height:48px;padding:10px 13px;background:var(--paper);color:var(--ink);border:1px solid var(--line);border-radius:8px}.private-settings{max-width:640px;margin-top:26px}.account-status{margin:14px 0 24px}.private-history{overflow-wrap:anywhere}</style></head><body><main class="shell"><header class="nav"><a class="brand" href="/">ZEC TIP BOT</a><a href="/account">My account</a></header>'+body+'<footer class="footer">TESTNET ONLY · Hosted wallets · Your X identity is known to the service</footer></main></body></html>';}
export function accountRoutes(c:Config,state:State,fetcher:typeof fetch=fetch,healthReader:(path:string)=>Promise<WalletHealth|undefined>=readWalletHealth,backend:AccountWalletBackend|undefined=c.walletAccounts?new WalletAccountClient(c.walletBrokerSocket):undefined) {
  const store=new TipStore(state), origin=new URL(c.baseUrl), secure=origin.protocol==='https:';
  const provisioner=backend?new WalletAccountProvisioner(store,backend):undefined;
  if (!secure && origin.hostname!=='127.0.0.1') throw new Error('Private accounts require HTTPS or explicit loopback.');
  const callback=new URL(c.userCallback);
  if(callback.origin!==origin.origin || callback.pathname!=='/account/callback' || callback.search || callback.hash)throw new Error('Invalid X_USER_CALLBACK_URL.');
  const sessionName=secure?'__Host-zec_account':'zec_account', loginName=secure?'__Host-zec_login':'zec_login';
  const cookieValue=(name:string,value:string,age:number)=>`${name}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${secure?'; Secure':''}`;
  const pending=new Map<string,{secret:string;browser:string;expires:number}>();
  return async(req:IncomingMessage,res:ServerResponse):Promise<boolean>=>{
    const url=new URL(req.url??'/',origin), path=url.pathname;
    if(path!=='/' && !path.startsWith('/account'))return false;
    res.setHeader('Cache-Control','no-store');// Keep same-origin form origin checks working; do not send callback query referrers.
    res.setHeader('Referrer-Policy',path==='/account/callback'?'no-referrer':'same-origin');res.setHeader('X-Robots-Tag','noindex, nofollow');
    res.setHeader('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; form-action 'self' https://api.x.com https://x.com https://api.twitter.com https://twitter.com; base-uri 'none'; frame-ancestors 'none'");
    res.setHeader('Content-Type','text/html; charset=utf-8');
    if(req.headers.host!==origin.host){res.writeHead(400).end('Invalid host.');return true;}
    if(!['GET','POST','HEAD'].includes(req.method??'')){res.writeHead(405).end();return true;}
    if(req.method==='HEAD'){res.end();return true;}
    const token=cookie(req,sessionName), session=store.session(token,c.network);
    const send=(body:string,status=200)=>{res.writeHead(status).end(page(body));};
    const redirect=(target:string)=>res.writeHead(303,{Location:target}).end();
    try {
      if(req.method==='GET' && path==='/') {
        send('<section class="hero"><div><span class="pill">TESTNET PREVIEW</span><h1>Tip in a comment.<br>Keep the amount private.</h1><p class="hero-copy">Choose your personal default once. Then comment <code>@zectipbot tip</code> under a post, or <code>@zectipbot tip @recipient</code>. Public comments reveal tipping intent, but never include your amount or address.</p></div><div class="composer"><h2>Your amount. Your limits.</h2><p>Sign in to save a default, daily cap and network-fee ceiling. Automatic transfers remain unavailable until the wallet backend is connected and verified.</p><a class="button" href="/account">Open my account</a><p class="hint">The operator knows your X-to-wallet association and controls hosted spending. No Mainnet deposits.</p></div></section>');return true;
      }
      if(req.method==='GET' && path==='/account' && !session) {
        const nonce=randomBytes(24).toString('hex');res.setHeader('Set-Cookie',cookieValue(loginName,nonce,600));
        send('<section class="guide"><h1>Your private settings</h1><p>Sign in with X to bind settings to your verified account. This is separate from the bot account authorization. It does not post or enable spending.</p><form method="post" action="/account/login"><input type="hidden" name="csrf" value="'+nonce+'"><button class="button" type="submit">Continue with X</button></form><p>Financial details stay out of public pages. X knows your sign-in and the service knows your account. Hosted funds are controlled by the service.</p></section>');return true;
      }
      if(req.method==='POST' && path==='/account/login') {
        const form=await fields(req), browser=cookie(req,loginName);
        if(req.headers.origin!==origin.origin || !/^[a-f0-9]{48}$/.test(browser) || form.get('csrf')!==browser){send('<h1>Sign-in could not be verified.</h1><p>Open a fresh account page and try again. Cookies must be enabled for this site.</p><a class="button" href="/account">Open sign-in page</a>',403);return true;}
        for(const [key,value] of pending)if(value.expires<=Date.now())pending.delete(key);
        if(pending.size>=100){send('Sign-in is busy. Please try later.',429);return true;}
        const result=await tokenRequest('request_token',{key:c.apiKey,secret:c.apiSecret},{oauth_callback:callback.href},fetcher);
        pending.set(result.get('oauth_token')!,{secret:result.get('oauth_token_secret')!,browser,expires:Date.now()+600_000});
        res.writeHead(303,{Location:'https://api.x.com/oauth/authorize?oauth_token='+encodeURIComponent(result.get('oauth_token')!)}).end();return true;
      }
      if(req.method==='GET' && path==='/account/callback') {
        const requestToken=url.searchParams.get('oauth_token')??'', verifier=url.searchParams.get('oauth_verifier')??'', entry=pending.get(requestToken);
        if(!entry || entry.expires<=Date.now() || entry.browser!==cookie(req,loginName) || url.searchParams.getAll('oauth_token').length!==1 || url.searchParams.getAll('oauth_verifier').length!==1 || !/^[A-Za-z0-9_-]{1,256}$/.test(verifier)){send('Sign-in expired or could not be matched. Open your account again.',403);return true;}
        pending.delete(requestToken);
        const result=await tokenRequest('access_token',{key:c.apiKey,secret:c.apiSecret,token:requestToken,tokenSecret:entry.secret},{oauth_verifier:verifier},fetcher);
        const credentials={key:c.apiKey,secret:c.apiSecret,token:result.get('oauth_token')!,tokenSecret:result.get('oauth_token_secret')!};
        const endpoint='https://api.x.com/2/users/me';state.reserveCost(10,c.budgetMills);
        const response=await fetcher(endpoint,{headers:{Authorization:oauthHeader('GET',endpoint,credentials)},redirect:'error',signal:AbortSignal.timeout(15_000)});
        if(!response.ok)throw new Error('Sign-in failed.');
        const identity=await response.json() as {data?:{id?:string;username?:string}};
        // User access credentials exist only in this callback's memory. Never write them to .env or SQLite.
        if(!identity.data?.id || !identity.data.username)throw new Error('Sign-in failed.');
        if(session)store.logout(token);
        const logged=store.login(identity.data.id,identity.data.username,c.network);
        res.setHeader('Set-Cookie',[cookieValue(sessionName,logged.token,3600),cookieValue(loginName,'',0)]);redirect('/account');return true;
      }
      if(!session){redirect('/account');return true;}
      if(req.method==='POST') {
        const form=await fields(req);
        if(req.headers.origin!==origin.origin || form.get('csrf')!==session.csrf){send('This form expired. Reload your account.',403);return true;}
        if(path==='/account/logout'){store.logout(token);res.setHeader('Set-Cookie',cookieValue(sessionName,'',0));redirect('/account');return true;}
        if(path==='/account/wallet') {
          if(!c.walletAccounts||!provisioner||c.network!=='testnet'){send('<h1>Wallet setup is not available yet.</h1><a href="/account">Back to my account</a>',503);return true;}
          if(Date.now()-session.created>600_000){send('<h1>Please sign in again before creating your wallet.</h1><p>Sign out, then continue with X again.</p><a href="/account">Back to my account</a>',403);return true;}
          if(form.get('wallet_consent')!=='yes'||[...form.keys()].some(key=>!['csrf','wallet_consent'].includes(key))){send('<h1>Confirm hosted Testnet wallet creation first.</h1><a href="/account">Back to my account</a>',400);return true;}
          try{await provisioner.provision(session.user_id);redirect('/account');}
          catch{send('<h1>Your wallet is not ready yet.</h1><p>Setup is waiting for wallet checks or reconciliation. Existing wallets were preserved. No payment was sent.</p><a class="button" href="/account">Back to my account</a>',503);}
          return true;
        }
        if(path==='/account/settings') {
          if(form.get('enabled')==='yes'&&(!c.hostedWallets||!backend||(await backend.health()).transfersEnabled!==true)){send('<h1>Automatic transfers are not available yet.</h1><p>Your wallet and saved preferences were preserved.</p><a href="/account">Back to my account</a>',400);return true;}
          try {store.settings(session.user_id,c.network,{amount:form.get('amount')??'',daily:form.get('daily')??'',fee:form.get('fee')??'',enabled:form.get('enabled')==='yes',publicAck:form.get('public_ack')==='yes',consent:form.get('consent')==='yes'},c.maxTip);}
          catch {send('<h1>Settings were not saved.</h1><p>Enter positive amounts with up to eight decimals. Your daily cap must cover the default plus the fee ceiling. Consent is required; enabling needs a verified Testnet wallet.</p><a href="/account">Back to settings</a>',400);return true;}
          redirect('/account');return true;
        }
        res.writeHead(404).end();return true;
      }
      if(path!=='/account'){res.writeHead(404).end();return true;}
      const p=store.profile(session.user_id,c.network)!, wallet=store.wallet(session.user_id,c.network), csrf=escape(session.csrf), val=(n:number|null)=>n===null?'':formatZat(n);
      let accountHealth:AccountWalletHealth|undefined;
      if(backend){try{accountHealth=await backend.health();}catch{/* Render unavailable; never upstream bodies. */}}
      let balance:WalletBalance|undefined;
      if(wallet?.status==='ready'&&accountHealth?.synced&&backend?.balance){try{balance=await backend.balance(wallet.account);}catch{/* Unavailable is not a zero balance. */}}
      const balancePanel=wallet?.status==='ready'?'<section class="composer private-settings"><span class="eyebrow muted">CONFIRMED TESTNET BALANCE</span><h2>'+(balance?escape(formatZat(balance.confirmedSpendableZat))+' Testnet ZEC':'Balance check pending')+'</h2><p>Spendable shielded funds with at least 10 confirmations. Network fees come from this balance.</p>'+(balance?.transparentBalancePresent?'<p>Transparent funds are not included in this shielded balance.</p>':'')+'<p class="hint">'+(accountHealth?.synced?'Wallet scan is up to date.':'Waiting for wallet synchronization.')+' Deposit and transfer controls remain held.</p></section>':'';
      const transfersReady=!!(c.hostedWallets&&accountHealth?.transfersEnabled&&accountHealth.synced);
      const setupPanel=c.walletAccounts?'<section class="composer private-settings"><span class="pill">YOUR TESTNET WALLET</span><h2>'+(wallet?.status==='ready'?'Created and linked to your X account':'One account. Your own tipping wallet.')+'</h2><p>'+(wallet?.status==='ready'?'Your wallet mapping is saved. Deposit and transfer checks are still in progress.':'Create a dedicated hosted Testnet wallet for this verified X account. Wallet creation costs no ZEC and enables no automatic payment.')+'</p>'+(wallet?.status==='ready'?'':'<form method="post" action="/account/wallet"><input type="hidden" name="csrf" value="'+csrf+'"><p><label><input type="checkbox" name="wallet_consent" value="yes" required> I understand this is a hosted Testnet wallet controlled by the service. My wallet address and X association stay out of public pages.</label></p><button class="button" type="submit" '+(!accountHealth?.accountCreationReady?'disabled':'')+'>Create my Testnet wallet</button></form>')+'<p class="hint">'+(accountHealth?.backupConfirmed?'Operator recovery verified. ':'Wallet checks pending. ')+(accountHealth?.accountCreationReady?'Account creation is ready.':'Waiting for account setup readiness.')+' Automatic transfers remain disabled.</p></section>':'';
      const healthPanel=(c.walletHealthFile?walletHealthPanel(await healthReader(c.walletHealthFile)):'')+setupPanel+balancePanel;
      const activity=store.history(session.user_id,c.network).map(job=>{
        const outgoing=job.sender===session.user_id,other=store.profile(outgoing?job.recipient:job.sender,c.network);
        const who=other?'@'+other.username:'recipient unavailable';
        const time=new Intl.DateTimeFormat('en-NG',{timeZone:'Africa/Lagos',dateStyle:'medium',timeStyle:'short'}).format(new Date(job.created));
        const status=({queued:'Accepted; awaiting wallet processing',submitted:'Submitted; awaiting confirmation',confirmed:'Confirmed',failed:'Not sent',review:'Needs review; do not retry'} as Record<string,string>)[job.status]??job.status;
        return '<li>'+escape(time)+' Lagos · '+(outgoing?'To ':'From ')+escape(who)+' · '+escape(formatZat(job.amount_zat))+' ZEC · '+escape(status)+(job.reason?' · '+escape(reasons[job.reason]??'Needs review.'):'')+'</li>';
      }).join('');
      send('<section class="guide"><span class="pill">TESTNET · HOSTED ACCOUNT</span><h1>@'+escape(p.username)+'</h1><p>Your tipping wallet: '+(wallet?.status==='ready'?'linked to your X account':'not provisioned — deposits and transfers unavailable')+'. Automatic tipping: '+(p.enabled&&transfersReady?'enabled':'disabled')+'.</p>'+healthPanel+(wallet?.status==='ready'&&accountHealth?.depositsEnabled?'<label class="field" for="deposit">Your private Testnet deposit address</label><textarea class="address" id="deposit" readonly>'+escape(wallet.address)+'</textarea>':'')+'<form class="composer private-settings" method="post" action="/account/settings"><h2>Your personal tip</h2><input type="hidden" name="csrf" value="'+csrf+'"><label class="field" for="amount">Default tip (ZEC)</label><input class="account-input" id="amount" name="amount" inputmode="decimal" required value="'+val(p.default_zat)+'" placeholder="For example, 0.001"><label class="field" for="daily">Daily spending cap, including fees (ZEC, resets at 01:00 Lagos)</label><input class="account-input" id="daily" name="daily" inputmode="decimal" required value="'+val(p.daily_zat)+'"><label class="field" for="fee">Maximum network fee per tip (ZEC)</label><input class="account-input" id="fee" name="fee" inputmode="decimal" required value="'+val(p.fee_zat)+'"><p><label><input type="checkbox" name="enabled" value="yes" '+(p.enabled&&transfersReady?'checked ':'')+(!transfersReady||wallet?.status!=='ready'?'disabled ':'')+'> Enable automatic comment tips</label></p><p><label><input type="checkbox" name="public_ack" value="yes" '+(p.public_ack?'checked':'')+'> Allow a generic public reply. No amounts or addresses.</label></p><p><label><input type="checkbox" name="consent" value="yes" required> I understand the service controls hosted funds. If enabled, my exact X commands authorize tips using these limits; X account compromise could spend that balance.</label></p><button class="button" type="submit">Save my settings</button><p class="hint">New settings apply only to new commands. No transfer is made by this form.</p></form><h2>Private activity</h2><ul class="private-history">'+activity+'</ul><p>Funds remain in your wallet if replies are stopped. Mainnet and withdrawals are not available in this preview; do not fund a service until withdrawal and recovery have been tested.</p><form method="post" action="/account/logout"><input type="hidden" name="csrf" value="'+csrf+'"><button class="button secondary" type="submit">Sign out</button></form></section>');return true;
    } catch(error) {
      const status=error instanceof Error ? /^OAuth (?:request_token|access_token) failed \(HTTP ([0-9]{3});/.exec(error.message)?.[1] : undefined;
      // Construct diagnostics from a validated status only. Never render upstream bodies or exception text.
      const detail=status?'X authorization failed (HTTP '+status+'). Check the additional callback URL and existing app permissions.':'Retry from a fresh account page. Existing settings were preserved.';
      send('<h1>Sign-in or account action could not finish.</h1><p>'+detail+'</p><p>No payment was sent by this page.</p><a class="button" href="/account">Open account</a>',400);return true;
    }
  };
}




